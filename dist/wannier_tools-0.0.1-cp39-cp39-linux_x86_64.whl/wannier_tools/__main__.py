#!/usr/bin/env python3
"""
WannierTools - Main entry point for command line execution
"""

from .cli import main

if __name__ == '__main__':
    main() 